from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, date


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    phone: str
    date_of_birth: str  # Format: YYYY-MM-DD
    profile_image: Optional[str] = None

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    profile_image: Optional[str] = None
    following: Optional[List[str]] = None

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    phone: str
    date_of_birth: str
    profile_image: Optional[str] = None
    followers: List[str] = Field(default_factory=list)
    following: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    phone: str
    date_of_birth: str
    profile_image: Optional[str]
    age: int
    followers_count: int
    following_count: int
    followers: List[str]
    following: List[str]

# Helper function to calculate age
def calculate_age(dob_str: str) -> int:
    try:
        birth_date = datetime.strptime(dob_str, "%Y-%m-%d").date()
        today = date.today()
        age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
        return age
    except:
        return 0

# Routes
@api_router.get("/")
async def root():
    return {"message": "User Management API"}

@api_router.post("/users", response_model=User)
async def create_user(user_input: UserCreate):
    # Check if email already exists
    existing = await db.users.find_one({"email": user_input.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already exists")
    
    user = User(**user_input.model_dump())
    doc = user.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    
    await db.users.insert_one(doc)
    return user

@api_router.get("/users", response_model=List[UserResponse])
async def get_users():
    users = await db.users.find({}, {"_id": 0}).to_list(1000)
    
    response = []
    for user in users:
        user_response = UserResponse(
            id=user['id'],
            name=user['name'],
            email=user['email'],
            phone=user['phone'],
            date_of_birth=user['date_of_birth'],
            profile_image=user.get('profile_image'),
            age=calculate_age(user['date_of_birth']),
            followers_count=len(user.get('followers', [])),
            following_count=len(user.get('following', [])),
            followers=user.get('followers', []),
            following=user.get('following', [])
        )
        response.append(user_response)
    
    return response

@api_router.get("/users/{user_id}", response_model=UserResponse)
async def get_user(user_id: str):
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return UserResponse(
        id=user['id'],
        name=user['name'],
        email=user['email'],
        phone=user['phone'],
        date_of_birth=user['date_of_birth'],
        profile_image=user.get('profile_image'),
        age=calculate_age(user['date_of_birth']),
        followers_count=len(user.get('followers', [])),
        following_count=len(user.get('following', [])),
        followers=user.get('followers', []),
        following=user.get('following', [])
    )

@api_router.put("/users/{user_id}", response_model=UserResponse)
async def update_user(user_id: str, user_update: UserUpdate):
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    update_data = {k: v for k, v in user_update.model_dump().items() if v is not None}
    
    if update_data:
        await db.users.update_one({"id": user_id}, {"$set": update_data})
    
    updated_user = await db.users.find_one({"id": user_id}, {"_id": 0})
    
    return UserResponse(
        id=updated_user['id'],
        name=updated_user['name'],
        email=updated_user['email'],
        phone=updated_user['phone'],
        date_of_birth=updated_user['date_of_birth'],
        profile_image=updated_user.get('profile_image'),
        age=calculate_age(updated_user['date_of_birth']),
        followers_count=len(updated_user.get('followers', [])),
        following_count=len(updated_user.get('following', [])),
        followers=updated_user.get('followers', []),
        following=updated_user.get('following', [])
    )

@api_router.delete("/users/{user_id}")
async def delete_user(user_id: str):
    result = await db.users.delete_one({"id": user_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Remove this user from others' followers and following lists
    await db.users.update_many(
        {"followers": user_id},
        {"$pull": {"followers": user_id}}
    )
    await db.users.update_many(
        {"following": user_id},
        {"$pull": {"following": user_id}}
    )
    
    return {"message": "User deleted successfully"}

@api_router.post("/users/{user_id}/follow/{target_user_id}")
async def follow_user(user_id: str, target_user_id: str):
    if user_id == target_user_id:
        raise HTTPException(status_code=400, detail="Cannot follow yourself")
    
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    target = await db.users.find_one({"id": target_user_id}, {"_id": 0})
    
    if not user or not target:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if already following
    if target_user_id in user.get('following', []):
        raise HTTPException(status_code=400, detail="Already following this user")
    
    # Add to following list
    await db.users.update_one(
        {"id": user_id},
        {"$push": {"following": target_user_id}}
    )
    
    # Add to target's followers list
    await db.users.update_one(
        {"id": target_user_id},
        {"$push": {"followers": user_id}}
    )
    
    return {"message": "Successfully followed user"}

@api_router.post("/users/{user_id}/unfollow/{target_user_id}")
async def unfollow_user(user_id: str, target_user_id: str):
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    target = await db.users.find_one({"id": target_user_id}, {"_id": 0})
    
    if not user or not target:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Remove from following list
    await db.users.update_one(
        {"id": user_id},
        {"$pull": {"following": target_user_id}}
    )
    
    # Remove from target's followers list
    await db.users.update_one(
        {"id": target_user_id},
        {"$pull": {"followers": user_id}}
    )
    
    return {"message": "Successfully unfollowed user"}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()